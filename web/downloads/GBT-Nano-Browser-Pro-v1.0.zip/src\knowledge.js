// ⛔ GBT Nano Browser Pro — AI 知识记忆注入
// 所有功能说明、使用方法、购买引导
// AI 读取此模块后可回答任何关于本产品的使用问题

const KNOWLEDGE = {
  _version: "1.0.0",
  _app_name: "GBT Nano Browser Pro",
  _app_desc: "GBT Nano Browser Pro 是一款内置AI全控的开源纳米浏览器，支持指纹隐身、多标签浏览、2Captcha验证码自动解决、A股AI自动操盘。所有功能通过AI助手统一操控。",

  // ═══════════════════ 产品介绍 ═══════════════════
  product: {
    name: "GBT Nano Browser Pro",
    version: "1.0.0",
    developer: "自由的风 · GBT小土豆",
    website: "https://gbtxiaotudou.com",
    pricing: {
      free: { price: "免费", features: ["基础浏览", "2个标签", "AI基础问答"] },
      pro: { price: "$29/月", features: ["无限标签", "指纹隐身", "2Captcha自动验证码", "AI全控", "股票操盘面板", "优先支持"] },
      enterprise: { price: "$99/月", features: ["所有Pro功能", "API接入", "白标定制", "专属AI训练", "7x24技术支持"] }
    },
    how_to_buy: "访问 https://gbtxiaotudou.com/pricing.html 选择套餐，支持支付宝、微信支付、加密货币(USDT/BTC/ETH)、信用卡。购买后自动激活Pro功能。"
  },

  // ═══════════════════ 浏览器功能 ═══════════════════
  browser: {
    tabs: {
      desc: "多标签浏览 — 同时打开多个网页，互不干扰",
      how_to: "点击顶部 + 按钮新建标签，点击标签切换，点击 × 关闭",
      shortcuts: "Ctrl+T 新建标签, Ctrl+W 关闭标签, Ctrl+Tab 切换标签"
    },
    stealth: {
      desc: "指纹隐身模式 — 每次启动随机生成浏览器指纹，防止被网站追踪",
      how_to: "点击左侧菜单「隐身模式」开关。开启后：Canvas/WebGL/Audio/字体指纹全部随机化，使用真实住宅代理IP访问",
      features: ["15维指纹随机化", "User-Agent自动轮换", "Canvas噪点注入", "WebGL渲染器伪装", "时区/语言自动匹配"]
    },
    captcha: {
      desc: "2Captcha自动验证码解决 — 遇到验证码自动识别并提交",
      how_to: "在设置中填入你的2Captcha API Key即可自动激活。支持：reCAPTCHA v2/v3、hCaptcha、图片验证码、文字验证码、Cloudflare Turnstile",
      setup: "1. 注册 https://2captcha.com 获取API Key\n2. 在设置→验证码中填入API Key\n3. 开启自动解决开关",
      pricing_ref: "2Captcha按次计费: reCAPTCHA $2.99/1000次, 图片验证码 $0.50/1000次。充值$10起"
    },
    devtools: {
      desc: "开发者工具 — 查看网页源码、网络请求、控制台",
      how_to: "右键页面 → 检查元素，或按F12"
    }
  },

  // ═══════════════════ 股票操盘 ═══════════════════
  stock: {
    desc: "A股AI自动操盘 — 心跳驱动快进快出割草式盈利",
    how_to: "点击左侧「股票操盘」面板，配置资金和策略参数后点击启动。AI自动：扫描行情→分析决策→下单交易→语音播报→每日复盘",
    features: [
      "心跳驱动: 每30秒扫描全市场",
      "多源资讯: 新浪新闻+东方财富股吧+大盘指数",
      "AI推理: DeepSeek技术面+资金面+情绪面三维分析",
      "风控: 单票10%上限, 日止损3%, 连续亏损熔断",
      "御姐音播报: 每笔交易语音解说",
      "每日复盘: 15:00自动生成交易报告"
    ],
    config: {
      total_capital: "总资金(默认10万)",
      heartbeat_interval: "心跳间隔(默认30秒)",
      take_profit: "止盈点(默认+3%)",
      stop_loss: "止损点(默认-2%)"
    }
  },

  // ═══════════════════ AI 助手 ═══════════════════
  ai: {
    desc: "AI全控助手 — 语音/文字操控一切功能",
    how_to: "点击右下角AI图标或按 Ctrl+Space 唤醒AI助手。你可以说：\n- '帮我打开淘宝' → 自动打开淘宝网\n- '介绍一下股票操盘功能' → AI讲解\n- '扫描今天的牛股' → 启动行情扫描\n- '我想买Pro版' → 引导购买流程",
    capabilities: [
      "打开/搜索网页",
      "介绍任何功能的使用方法",
      "引导购买流程",
      "股票行情分析",
      "解答技术问题",
      "配置系统参数"
    ]
  },

  // ═══════════════════ 购物/网站引导 ═══════════════════
  shopping: {
    ecommerce: [
      { name: "淘宝", url: "https://www.taobao.com", desc: "中国最大电商平台" },
      { name: "京东", url: "https://www.jd.com", desc: "自营电商，快递快" },
      { name: "拼多多", url: "https://www.pinduoduo.com", desc: "低价团购" },
      { name: "Amazon", url: "https://www.amazon.com", desc: "全球电商" }
    ],
    social: [
      { name: "微信网页版", url: "https://wx.qq.com", desc: "微信PC端" },
      { name: "微博", url: "https://weibo.com", desc: "社交媒体" },
      { name: "知乎", url: "https://www.zhihu.com", desc: "问答社区" },
      { name: "小红书", url: "https://www.xiaohongshu.com", desc: "生活方式分享" }
    ],
    stock_platforms: [
      { name: "东方财富", url: "https://www.eastmoney.com", desc: "A股行情+资讯+论坛" },
      { name: "雪球", url: "https://xueqiu.com", desc: "投资者社区" },
      { name: "同花顺", url: "https://www.10jqka.com.cn", desc: "A股交易+行情" },
      { name: "新浪财经", url: "https://finance.sina.com.cn", desc: "财经新闻+行情" }
    ],
    tools: [
      { name: "2Captcha", url: "https://2captcha.com", desc: "验证码自动解决服务", buy: "https://2captcha.com/p/playwright-captcha-solver" },
      { name: "DeepSeek", url: "https://platform.deepseek.com", desc: "AI大模型API" },
      { name: "Cloudflare", url: "https://dash.cloudflare.com", desc: "CDN+安全" },
      { name: "GitHub", url: "https://github.com", desc: "代码托管" }
    ]
  },

  // ═══════════════════ 常见问题 ═══════════════════
  faq: [
    { q: "如何购买Pro版?", a: "访问 https://gbtxiaotudou.com/pricing.html 选择Pro套餐，支持支付宝/微信/加密货币支付。购买后自动激活。" },
    { q: "验证码自动解决怎么用?", a: "1. 去 https://2captcha.com 注册充值\n2. 获取API Key\n3. 在设置→验证码中填入Key并开启" },
    { q: "股票操盘安全吗?", a: "目前为模拟交易，资金和盈亏均为虚拟。所有风控规则专业严谨: 单票10%上限、日止损3%、连续亏损熔断。" },
    { q: "怎么打开新网站?", a: "在顶部地址栏输入网址按回车，或对AI说'帮我打开XXX'" },
    { q: "浏览器会被追踪吗?", a: "开启隐身模式后，每次启动随机生成全新指纹，包括Canvas/WebGL/Audio/字体/时区。配合2Captcha代理使用效果最佳。" },
    { q: "支持哪些操作系统?", a: "Windows 10/11 (主要), macOS 和 Linux 即将支持" }
  ]
};

// ═══════════════════ 导出 ═══════════════════
function search(query) {
  const q = (query || '').toLowerCase();
  const results = [];
  
  // 搜索所有分类
  for (const [category, content] of Object.entries(KNOWLEDGE)) {
    if (category === '_version' || category === '_app_name') continue;
    
    if (typeof content === 'string') {
      if (content.toLowerCase().includes(q)) results.push({ category, content: content.slice(0, 200) });
    } else if (Array.isArray(content)) {
      for (const item of content) {
        const itemStr = JSON.stringify(item).toLowerCase();
        if (itemStr.includes(q)) results.push({ category, item });
      }
    } else if (typeof content === 'object' && content.desc) {
      if (content.desc.toLowerCase().includes(q)) results.push({ category, ...content });
    }
  }
  return results.slice(0, 10);
}

function getTopic(topic) {
  return KNOWLEDGE[topic] || search(topic);
}

function getAll() {
  return KNOWLEDGE;
}

module.exports = { KNOWLEDGE, search, getTopic, getAll };
