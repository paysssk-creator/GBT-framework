// GBT Nano Browser Pro — Electron Main Process
// AI全控 · 指纹隐身 · 2Captcha · 股票操盘
const { app, BrowserWindow, session, ipcMain, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow;
let bridgeProcess = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600,
    frame: false, titleBarStyle: 'hidden',
    backgroundColor: '#0a0a0f',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false, contextIsolation: true,
      webviewTag: true, sandbox: false,
    }
  });

  // ── 拦截外部导航 → 全部关在应用内 ──
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    mainWindow.loadURL(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('did-create-window', (child) => {
    child.webContents.on('will-navigate', (e, url) => {
      e.preventDefault();
      mainWindow.loadURL(url);
    });
  });

  // CDP: AI 全控
  mainWindow.webContents.debugger.attach('1.3');

  // 所有权限放行
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(true));

  // 指纹隐身 — 每次启动随机指纹
  injectFingerprint();

  mainWindow.loadFile(path.join(__dirname, '..', 'src', 'index.html'));

  // 启动 Python AI 桥接
  startBridge();
}

// ═══════════════════ 指纹隐身引擎 ═══════════════════
function injectFingerprint() {
  const uaPool = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0',
  ];
  const ua = uaPool[Math.floor(Math.random() * uaPool.length)];
  session.defaultSession.webRequest.onBeforeSendHeaders((details, cb) => {
    details.requestHeaders['User-Agent'] = ua;
    cb({ requestHeaders: details.requestHeaders });
  });
  // Canvas/WebGL/Audio 指纹随机化通过 preload 注入
}

// ═══════════════════ Python AI 桥接 ═══════════════════
function startBridge() {
  const bridgePath = path.join(__dirname, '..', 'server', 'bridge.py');
  bridgeProcess = spawn('python', [bridgePath], {
    cwd: path.join(__dirname, '..'),
    stdio: ['pipe', 'pipe', 'pipe']
  });
  bridgeProcess.stdout.on('data', (d) => console.log('[Bridge]', d.toString().trim()));
  bridgeProcess.stderr.on('data', (d) => console.error('[Bridge ERR]', d.toString().trim()));
  bridgeProcess.on('close', (code) => {
    console.log('[Bridge] exited with', code);
    if (code !== 0) setTimeout(startBridge, 5000); // 自动重连
  });
}

// ═══════════════════ IPC: AI 命令 ═══════════════════
ipcMain.handle('ai-ask', async (event, { question, context }) => {
  try {
    const resp = await fetch('http://localhost:15999/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, context })
    });
    return await resp.json();
  } catch (e) {
    return { ok: false, error: 'AI桥接未连接' };
  }
});

ipcMain.handle('ai-open-url', async (event, { url }) => {
  mainWindow.loadURL(url);
  return { ok: true };
});

ipcMain.handle('ai-stock-status', async () => {
  try {
    const resp = await fetch('http://localhost:8766/api/status');
    return await resp.json();
  } catch (e) {
    return { running: false };
  }
});

ipcMain.handle('get-knowledge', async (event, { topic }) => {
  const knowledge = require('../src/knowledge.js');
  return knowledge.getTopic(topic);
});

ipcMain.handle('search-knowledge', async (event, { query }) => {
  const knowledge = require('../src/knowledge.js');
  return knowledge.search(query);
});

// ═══════════════════ 生命周期 ═══════════════════
app.whenReady().then(createWindow);
app.on('window-all-closed', () => {
  if (bridgeProcess) bridgeProcess.kill();
  app.quit();
});
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
