# GBT Nano Browser Pro — AI Bridge Server
# 连接 Electron ↔ AI引擎 ↔ 股票操盘
import http.server, json, subprocess, sys, os, time, threading
from pathlib import Path

PORT = 15999
GBT_ROOT = Path(__file__).parent.parent.parent.parent  # GBTxiaotudouV5

sys.path.insert(0, str(GBT_ROOT))

class AIHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            n = int(self.headers.get('Content-Length', 0))
            d = json.loads(self.rfile.read(n))
            
            if self.path == '/ai':
                question = d.get('question', '')
                # 调用 deep_reasoner
                try:
                    from brain.deep_reasoner import get_reasoner
                    reasoner = get_reasoner()
                    result = reasoner.reason(question, mode="decision")
                    resp = {"ok": True, "answer": str(result)[:2000]}
                except Exception as e:
                    resp = {"ok": True, "answer": f"AI引擎离线: {e}"}
            elif self.path == '/cmd':
                cmd = d.get('cmd', '')
                r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
                resp = {"ok": True, "stdout": r.stdout[:2000], "stderr": r.stderr[:500]}
            elif self.path == '/stock':
                try:
                    r = subprocess.run(
                        [sys.executable, str(GBT_ROOT / 'caps' / 'stock_scalper' / 'run.py'), d.get('action', 'status')],
                        capture_output=True, text=True, timeout=15, cwd=str(GBT_ROOT))
                    resp = json.loads(r.stdout) if r.stdout.strip() else {"ok": False}
                except:
                    resp = {"ok": False, "error": "股票引擎未启动"}
            else:
                resp = {"ok": False, "error": "unknown path"}
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(resp, ensure_ascii=False).encode('utf-8'))
        except Exception as e:
            self.send_response(500); self.end_headers()
            self.wfile.write(json.dumps({"ok": False, "error": str(e)}).encode())
    
    def do_GET(self):
        self.send_response(200); self.end_headers()
        self.wfile.write(json.dumps({"status": "ok", "port": PORT, "gbt_root": str(GBT_ROOT)}).encode())
    
    def log_message(self, *a): pass

if __name__ == '__main__':
    print(f'GBT Bridge starting on port {PORT}...', flush=True)
    http.server.HTTPServer(('127.0.0.1', PORT), AIHandler).serve_forever()
